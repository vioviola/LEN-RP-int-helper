/* RP Int 预填助手 — 设置页逻辑。 */
(function () {
  'use strict';
  const U = RPUtil, S = RPStore;
  const $ = (id) => document.getElementById(id);

  let defaults = {};
  let people = [];
  let fields = [];

  function send(type, payload) {
    return new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const t = (tabs && tabs[0]) || {};
        if (!t.id) { resolve({ error: '找不到当前标签页' }); return; }
        chrome.tabs.sendMessage(t.id, Object.assign({ type: type }, payload || {}), (r) => {
          if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
          else resolve(r || { error: '无响应（请确认已打开 RP 录入页）' });
        });
      });
    });
  }

  function renderDefaults() {
    const keys = Object.keys(defaults);
    $('defRows').innerHTML = keys.length ? keys.map((k) => {
      const d = defaults[k] || {};
      const st = Number(d.stage) === 1 ? 1 : 2;
      return '<tr>' +
        '<td><input type="checkbox" data-en="' + U.escapeHtml(k) + '"' + (d.enabled !== false ? ' checked' : '') + '></td>' +
        '<td><input type="text" data-dk="' + U.escapeHtml(k) + '" value="' + U.escapeHtml(k) + '">' +
          (fields.find((f) => f.displayName === k)
            ? '<span class="muted" style="font-size:11px">' + U.escapeHtml(fields.find((f) => f.displayName === k).schemaName) + '</span>'
            : '') + '</td>' +
        '<td><input type="text" data-dv="' + U.escapeHtml(k) + '" value="' +
          U.escapeHtml(d.value == null ? '' : d.value) + '"></td>' +
        '<td><select data-st="' + U.escapeHtml(k) + '" style="width:100%;font-size:12px">' +
          '<option value="2"' + (st === 2 ? ' selected' : '') + '>人员</option>' +
          '<option value="1"' + (st === 1 ? ' selected' : '') + '>①触发</option>' +
        '</select></td>' +
        '<td><button data-rm="' + U.escapeHtml(k) + '" style="padding:1px 6px">×</button></td>' +
      '</tr>';
    }).join('') : '<tr><td colspan="5" class="muted">还没有默认值，点「新增默认字段」创建。</td></tr>';
  }

  function renderPeople() {
    $('pCount').textContent = people.length;
    $('pRows').innerHTML = people.length ? people.map((p) =>
      '<tr><td>' + U.escapeHtml(p.name) + '</td>' +
      '<td class="muted">' + Object.keys(p.fields).length + '</td>' +
      '<td><button data-rmp="' + U.escapeHtml(p.id) + '" style="padding:1px 6px">×</button></td></tr>'
    ).join('') : '<tr><td colspan="3" class="muted">暂无人员</td></tr>';
  }

  function renderFields(list, tip) {
    fields = list || [];
    if (!fields.length) {
      $('fieldTable').style.display = 'none';
      $('probeTip').textContent = tip || '未探测到字段。';
      return;
    }
    $('fieldTable').style.display = '';
    $('probeTip').textContent = tip || ('共 ' + fields.length + ' 个字段');
    $('fieldRows').innerHTML = fields.map((f) =>
      '<tr><td>' + U.escapeHtml(f.displayName || '') + (f.required ? ' *' : '') + '</td>' +
      '<td class="muted">' + U.escapeHtml(f.schemaName) + '</td>' +
      '<td>' + U.escapeHtml(f.control || '') + '</td></tr>').join('');
  }

  function collectDefaults() {
    const out = {};
    $('defRows').querySelectorAll('input[data-dk]').forEach((nameEl) => {
      const key = String(nameEl.value || '').trim();
      if (!key) return;
      const v = $('defRows').querySelector('input[data-dv="' + CSS.escape(key) + '"]');
      const e = $('defRows').querySelector('input[data-en="' + CSS.escape(key) + '"]');
      const s = $('defRows').querySelector('select[data-st="' + CSS.escape(key) + '"]');
      const meta = fields.find((f) => f.displayName === key || f.schemaName === key);
      out[key] = {
        value: v ? String(v.value || '').trim() : '',
        enabled: e ? e.checked : true,
        control: meta ? (meta.control || 'text') : 'text',
        stage: s ? Number(s.value) : 2
      };
    });
    return out;
  }

  async function saveAll() {
    defaults = collectDefaults();
    await S.saveDefaults(defaults);
    $('saveTip').innerHTML = '<span class="badge ok">已保存</span> ' + Object.keys(defaults).length + ' 个默认值';
  }

  $('btnAddDef').addEventListener('click', () => {
    const n = prompt('字段的 schema 名（如 yearmonth）：');
    if (!n || !n.trim()) return;
    defaults[n.trim()] = { value: '', enabled: true, control: 'text' };
    renderDefaults();
  });

  $('defRows').addEventListener('click', (e) => {
    const rm = e.target.closest('[data-rm]');
    if (rm) { delete defaults[rm.getAttribute('data-rm')]; renderDefaults(); }
  });

  $('pRows').addEventListener('click', async (e) => {
    const rm = e.target.closest('[data-rmp]');
    if (!rm) return;
    if (!confirm('删除该人员？')) return;
    await S.removePerson(rm.getAttribute('data-rmp'));
    people = await S.getPeople();
    renderPeople();
  });

  $('btnSave').addEventListener('click', saveAll);

  $('btnProbe').addEventListener('click', async () => {
    const b = $('btnProbe'); b.disabled = true; b.textContent = '探测中…';
    const r = await send('RP_PROBE');
    b.disabled = false; b.textContent = '重新探测当前页';
    if (r && r.error) { $('probeTip').textContent = '探测失败：' + r.error; return; }
    await S.saveCache({ at: Date.now(), url: r.url, fields: r.fields, rendered: r.rendered, source: r.source });
    renderFields(r.fields.length ? r.fields : r.rendered,
      '来源：' + (r.source === 'webapi' ? 'Web API 元数据' : 'DOM 扫描') + '，共 ' +
      (r.fields.length || r.rendered.length) + ' 项');
  });

  $('btnExportAll').addEventListener('click', () => {
    if (!people.length) { alert('人员库为空。'); return; }
    const keys = [];
    people.forEach((p) => Object.keys(p.fields).forEach((k) => { if (keys.indexOf(k) < 0) keys.push(k); }));
    const lines = [['姓名'].concat(keys).join('\t')];
    people.forEach((p) => lines.push([p.name].concat(keys.map((k) => p.fields[k] == null ? '' : p.fields[k])).join('\t')));
    const blob = new Blob([lines.join('\n')], { type: 'text/tab-separated-values;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'rp-people.tsv';
    a.click();
    URL.revokeObjectURL(a.href);
  });

  $('btnBack').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = (tabs && tabs[0]) || {};
      if (t.id && t.url && t.url.indexOf('lenovo-ironman-prod') >= 0) {
        chrome.sidePanel.open({ tabId: t.id });
      } else {
        chrome.tabs.create({ url: chrome.runtime.getURL('sidepanel.html') });
      }
    });
  });

  (async function init() {
    defaults = await S.getDefaults();
    people = await S.getPeople();
    const cache = await S.getCache();
    renderDefaults(); renderPeople();
    if (cache) {
      renderFields(cache.fields && cache.fields.length ? cache.fields : cache.rendered,
        '上次探测缓存（' + (cache.fields && cache.fields.length ? cache.fields.length : (cache.rendered || []).length) + ' 项）');
    }
  })();
})();
