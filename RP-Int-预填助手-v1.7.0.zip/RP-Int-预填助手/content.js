/* RP Int 预填助手 — content script。
   职责：① 探测 目标系统 实体表单的字段结构；② 按计划填充字段；③ 页面结构诊断。
   注意：manifest 里 all_frames=true，目标系统 的表单可能渲染在 iframe 中，
   每个 frame 都会注入本脚本；由 isTop 决定是否作为主入口响应消息。 */
(function () {
  'use strict';

  const ENTITY = 'ironman_resourceplan';
  const HOST = 'lenovo-ironman-prod.crm5.dynamics.com';
  const meta = RPProbe;
  const isTop = (window.top === window.self);

  /* ---------- 元数据获取：多路径回退 ---------- */
  const META_PATHS = [
    '/api/data/v9.2/EntityDefinitions(LogicalName=\'' + ENTITY + '\')/Attributes?$select=LogicalName,SchemaName,AttributeType,AttributeFormat,RequiredLevel,MaxLength,Description,DisplayName,OptionSet,Targets',
    '/api/data/v9.1/EntityDefinitions(LogicalName=\'' + ENTITY + '\')/Attributes?$select=LogicalName,SchemaName,AttributeType,AttributeFormat,RequiredLevel,MaxLength,Description,DisplayName,OptionSet,Targets',
    '/api/data/v9.0/EntityDefinitions(LogicalName=\'' + ENTITY + '\')/Attributes?$select=LogicalName,SchemaName,AttributeType,AttributeFormat,RequiredLevel,MaxLength,Description,DisplayName,OptionSet,Targets'
  ];

  /** 返回 {list, path, status} 或 {error, status} */
  async function fetchMetadataOnce(path) {
    try {
      const res = await fetch('https://' + HOST + path, {
        credentials: 'include',
        headers: { Accept: 'application/json; odata.metadata=none' }
      });
      if (!res.ok) {
        let body = '';
        try { body = (await res.text()).slice(0, 300); } catch (e) { /* noop */ }
        return { error: 'HTTP ' + res.status + ' ' + res.statusText, status: res.status, body: body };
      }
      const json = await res.json();
      const list = json.value || json;
      if (!Array.isArray(list) || !list.length) return { error: '返回为空', status: res.status };
      return { list: list, status: res.status };
    } catch (e) {
      return { error: String(e && e.message), status: 0 };
    }
  }

  /** 依次尝试各 API 版本；失败原因逐条带回，便于定位是权限还是路径问题 */
  async function fetchMetadata() {
    const attempts = [];
    for (const path of META_PATHS) {
      const r = await fetchMetadataOnce(path);
      if (r.list) return { list: r.list, attempts: attempts, ok: path };
      attempts.push({ path: path.split('?')[0], error: r.error, status: r.status, body: r.body || '' });
    }
    return { list: null, attempts: attempts };
  }

  /* ---------- iframe 支持 ---------- */
  /** 列出可访问的同源 iframe 文档 */
  function accessibleFrames(win) {
    const out = [];
    let frames = [];
    try { frames = Array.from(win.document.querySelectorAll('iframe')); } catch (e) { return out; }
    frames.forEach((f, i) => {
      try {
        const doc = f.contentDocument;
        if (!doc) return;
        // 空白 iframe 也算（React 挂载前可能是空的）
        out.push({ index: i, win: f.contentWindow, doc: doc, src: f.getAttribute('src') || '' });
      } catch (e) {
        // 跨域 → contentDocument 为 null 或抛错
      }
    });
    return out;
  }

  /** 在主文档 + 所有可访问 iframe 里合并扫描结果 */
  function scanAllFrames() {
    const merged = [];
    const diag = [];
    const docs = [{ name: 'top', doc: document, win: window }].concat(
      accessibleFrames(window).map((f) => ({ name: 'iframe#' + f.index, doc: f.doc, win: f.win }))
    );
    docs.forEach((d) => {
      let found = [];
      try { found = RPFiller.scanRenderedFields(d.doc); } catch (e) { found = []; }
      diag.push({
        frame: d.name,
        url: (() => { try { return d.win.location.href.slice(0, 160); } catch (e) { return '(跨域)'; } })(),
        readyState: d.doc.readyState,
        found: found.length
      });
      found.forEach((f) => {
        f.frame = d.name;
        merged.push(f);
      });
    });
    return { fields: merged, diag: diag };
  }

  /* ---------- 对外能力 ---------- */
  async function probe() {
    const metaRes = await fetchMetadata();
    const scan = scanAllFrames();
    return {
      entity: ENTITY,
      fields: metaRes.list ? meta.normalizeAttributes(metaRes.list) : [],
      rendered: scan.fields,
      frameScan: scan.diag,
      metaAttempts: metaRes.attempts || [],
      source: metaRes.list ? 'webapi' : 'dom',
      url: location.href,
      at: Date.now()
    };
  }

  /** 诊断：把页面真实结构导出，用于排查「探测不到字段」 */
  function diagnose() {
    const top = RPFiller.diagnose(document, document);
    const frames = accessibleFrames(window).map((f, i) => {
      try {
        const d = RPFiller.diagnose(f.doc, f.doc);
        return {
          frame: 'iframe#' + i,
          src: (f.src || '').slice(0, 160),
          reachable: true,
          inner: d
        };
      } catch (e) {
        return { frame: 'iframe#' + i, src: (f.src || '').slice(0, 160), reachable: false, error: String(e && e.message) };
      }
    });
    return {
      url: location.href,
      isTop: isTop,
      top: top,
      frames: frames
    };
  }

  /** 填充：在主文档与 iframe 里一起找（两阶段为异步） */
  async function fill(plan, displayMap, opts) {
    const docs = [{ name: 'top', doc: document }].concat(
      accessibleFrames(window).map((f) => ({ name: 'iframe#' + f.index, doc: f.doc }))
    );
    // 两阶段：先填触发字段 → 等联动展开 → 再找新字段
    if ((opts && opts.twoStage) || plan.some((p) => Number(p.stage) === 1)) {
      let last = null;
      for (const d of docs) {
        let r = null;
        try {
          r = await RPFiller.fillTwoStage(d.doc, plan, displayMap, opts || {});
        } catch (e) {
          r = { total: 0, ok: 0, failed: plan.length, results: [],
                error: '异常：' + (e && e.message) };
        }
        if (!last) last = r;
        const stage1Ok = (r.results || []).filter((x) => x.stage === 1 && x.ok).length;
        const stage2Ok = (r.results || []).filter((x) => x.stage === 2 && x.ok).length;
        // 已经在某个 frame 里把两阶段都填成功了，就不再往下一个 frame 填，避免重复
        if (stage1Ok > 0 && stage2Ok > 0) { last = r; break; }
        // 没有阶段 2 字段时，阶段 1 成功即止
        if (stage2Ok === 0 && stage1Ok > 0 &&
            !(r.results || []).some((x) => x.stage === 2)) { last = r; break; }
      }
      return last;
    }

    const results = [];
    for (const item of plan) {
      let r = null;
      for (const d of docs) {
        try {
          const x = await RPFiller.fillField(d.doc, item, displayMap);
          if (x && x.ok) { x.frame = d.name; r = x; break; }
          if (!r && x) r = x;   // 记住最后一次失败，便于回报
        } catch (e) {
          r = { schemaName: item.schemaName, ok: false, reason: '异常：' + (e && e.message) };
        }
      }
      if (!r) r = { schemaName: item.schemaName, ok: false, reason: '未尝试任何文档' };
      results.push(r);
    }
    const okCount = results.filter((r) => r.ok).length;
    return {
      total: results.length,
      ok: okCount,
      failed: results.length - okCount,
      needConfirm: results.filter((r) => r.needsConfirm).map((r) => r.schemaName),
      results: results
    };
  }

  /* ---------- 真人动作（CDP 可信输入）的坐标与状态支撑 ----------
     background 用 CDP 在「顶层视口坐标」里派发可信鼠标事件，
     所以这里给出的坐标必须把 iframe 的偏移累计进去。 */
  function allDocs() {
    return [{ name: 'top', doc: document, win: window }].concat(
      accessibleFrames(window).map((f) => ({ name: 'iframe#' + f.index, doc: f.doc, win: f.win }))
    );
  }

  /** 元素中心点相对顶层视口的坐标（逐层累加祖先 iframe 的偏移） */
  function pageRectOf(el) {
    const r = el.getBoundingClientRect ? el.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };
    let x = (r.left || 0) + (r.width || 0) / 2;
    let y = (r.top || 0) + (r.height || 0) / 2;
    let win = el.ownerDocument && el.ownerDocument.defaultView;
    let guard = 0;
    while (win && win.parent && win !== win.parent && win.frameElement && guard < 6) {
      const fr = win.frameElement.getBoundingClientRect();
      x += fr.left || 0; y += fr.top || 0;
      win = win.parent; guard++;
    }
    return {
      x: Math.round(x), y: Math.round(y),
      w: Math.round(r.width || 0), h: Math.round(r.height || 0),
      left: Math.round(r.left || 0), top: Math.round(r.top || 0)
    };
  }

  /** 下拉触发器（optionset / lookup 的可点区域） */
  function triggerOf(container) {
    if (!container) return null;
    return container.querySelector(
      'button[role="combobox"], [aria-haspopup="listbox"], [role="combobox"], ' +
      '.msl-dropdown__select, .msl-dropdown, select, input[role="combobox"], button'
    );
  }

  /** 下拉当前显示的值。
      注意 aria-label 是字段名（如 "Source Type"）不是值，必须与值区分开。 */
  function triggerDisplay(el) {
    if (!el) return '';
    if ((el.tagName || '').toLowerCase() === 'select') {
      const o = el.options && el.options[el.selectedIndex];
      return o ? String(o.textContent || '').trim() : '';
    }
    if ((el.tagName || '').toLowerCase() === 'input') return String(el.value || '').trim();
    const aria = String(el.getAttribute ? (el.getAttribute('aria-label') || '') : '').trim();
    const inner = el.querySelector ? el.querySelector('span, div') : null;
    const t = String((inner && inner.textContent) || el.textContent || '').trim();
    // 显示文本与字段名相同 → 说明还没选值
    return t && t !== aria ? t : '';
  }

  /** 读取控件当前的值：输入框取 value，触发器取显示文本。
      必须区分这两者 —— 回读读错元素会让「输入自检」永远判定失败，
      从而触发第二次输入（真实事故：FY26 被输成 FY26FY26）。 */
  function valueOfEl(el) {
    if (!el) return '';
    const tag = String(el.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea') return String(el.value || '').trim();
    return triggerDisplay(el);
  }

  /** 按用途挑元素：mode='input' 要能打字的输入框；否则要能点开下拉的触发器 */
  function elementFor(container, mode) {
    if (!container) return null;
    const input = container.querySelector('input:not([type="hidden"]):not([disabled])');
    const trig = triggerOf(container);
    return String(mode) === 'input' ? (input || trig) : (trig || input);
  }

  function describeEl(el) {
    if (!el) return { tag: '', role: '', id: '' };
    return {
      tag: String(el.tagName || '').toLowerCase(),
      role: String(el.getAttribute ? (el.getAttribute('role') || '') : ''),
      id: String(el.id || '')
    };
  }

  /** 定位字段的下拉触发器，并滚动到可见区域后返回坐标 */
  async function humanLocate(spec) {
    for (const d of allDocs()) {
      let c = null;
      try { c = RPFiller.findContainer(d.doc, spec && spec.schemaName, spec && spec.displayName); }
      catch (e) { c = null; }
      if (!c) continue;
      const el = elementFor(c, spec && spec.mode);
      if (!el) continue;
      try { el.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (e) { /* noop */ }
      await new Promise((r) => setTimeout(r, 220));
      let count = 0;
      try { count = RPFiller.containersOf(d.doc).length; } catch (e) { count = 0; }
      const label = RPFiller.displayNameOf(el, c) || '';
      // 不再做「串台告警」：实际表单操作是对的，标签与期望的微小差异（如「Project」vs「Project, Lookup」）
      // 只是 目标系统 控件显示文案的差别，不构成定位错误，弹告警只会误导用户。
      return Object.assign({
        ok: true,
        rect: pageRectOf(el),
        label: label,
        display: valueOfEl(el),
        value: valueOfEl(el),
        frame: d.name,
        fieldCount: count,
        warn: ''
      }, describeEl(el));
    }
    return {
      ok: false,
      reason: '页面没找到字段「' + ((spec && (spec.displayName || spec.schemaName)) || '?') + '」的下拉控件'
    };
  }

  /** 列出当前已展开的所有下拉选项（带坐标） */
  /** 最新弹出的列表容器（目标系统 的 flyout/下拉通常 append 到末尾）。
      只从它里面取选项，避免把上一步下拉的**残留选项**当成当前搜索结果
      —— 否则「点第一条」会点到别的字段上。 */
  function latestListbox(doc) {
    let boxes = [];
    try {
      boxes = Array.from(doc.querySelectorAll(
        '[role="listbox"], [role="list"], ul.msl-listbox, .msl-dropdown, [data-id*="flyout"]'));
    } catch (e) { return null; }
    const vis = boxes.filter((b) => {
      const r = b.getBoundingClientRect ? b.getBoundingClientRect() : null;
      return !!r && (r.width > 0 || r.height > 0);
    });
    return vis.length ? vis[vis.length - 1] : null;
  }

  function humanOptions() {
    const out = [];
    // 末两项是 Lookup 搜索结果（目标系统 的 flyout 是 ul[role=listbox] + li）
    const SEL = '[role="option"], li[role="option"], .msl-dropdown__option, ' +
      '.msl-listbox__option, [role="listbox"] [data-value], [role="listbox"] li';
    allDocs().forEach((d) => {
      let cands = [];
      const box = latestListbox(d.doc);
      if (box) { try { cands = Array.from(box.querySelectorAll(SEL)); } catch (e) { cands = []; } }
      if (!cands.length) {
        // 认不出容器就退回全局扫描（老行为）
        try { cands = Array.from(d.doc.querySelectorAll(SEL)); } catch (e) { return; }
      }
      cands.forEach((o) => {
        if (o.getAttribute && o.getAttribute('aria-hidden') === 'true') return;
        if (o.style && (o.style.display === 'none' || o.style.visibility === 'hidden')) return;
        const rect = pageRectOf(o);
        if (rect.w === 0 && rect.h === 0) return;   // 不可见（未渲染/被折叠）
        out.push({
          text: String(o.textContent || '').trim(),
          rect: rect,
          id: String(o.id || ''),
          selected: String(o.getAttribute ? (o.getAttribute('aria-selected') || '') : '') === 'true',
          frame: d.name
        });
      });
    });
    return out;
  }

  /** 键盘走位时当前高亮的选项（aria-activedescendant） */
  function humanActive() {
    let host = null;
    try { host = document.activeElement; } catch (e) { host = null; }
    let id = host && host.getAttribute ? host.getAttribute('aria-activedescendant') : '';
    if (!id) {
      const h2 = document.querySelector('[aria-activedescendant]');
      id = h2 ? h2.getAttribute('aria-activedescendant') : '';
    }
    if (!id) return { text: '' };
    const el = document.getElementById(id);
    return { text: el ? String(el.textContent || '').trim() : '' };
  }

  /** 列出页面上所有下拉类字段（标签 / schema / 当前值）——
      用于核对「Type 到底叫什么、schema 名是不是 sample_type」 */
  function humanList() {
    const out = [];
    allDocs().forEach((d) => {
      let cs = [];
      try { cs = RPFiller.containersOf(d.doc); } catch (e) { return; }
      cs.forEach((c) => {
        const el = RPFiller.inputOf(c);
        if (!el) return;
        const role = String(el.getAttribute ? (el.getAttribute('role') || '') : '');
        const tag = String(el.tagName || '').toLowerCase();
        const hasPopup = String(el.getAttribute ? (el.getAttribute('aria-haspopup') || '') : '');
        if (role !== 'combobox' && tag !== 'select' && hasPopup !== 'listbox') return;
        out.push({
          label: RPFiller.displayNameOf(el, c) || '',
          schema: RPFiller.identifyField(el, c) || '',
          display: triggerDisplay(el),
          frame: d.name
        });
      });
    });
    return out;
  }

  /** 回读：字段当前显示值 + 页面字段总数（判断是否联动展开） */
  function humanVerify(spec) {
    for (const d of allDocs()) {
      let c = null;
      try { c = RPFiller.findContainer(d.doc, spec && spec.schemaName, spec && spec.displayName); }
      catch (e) { c = null; }
      if (!c) continue;
      // mode='input' → 读输入框的 value（文本/搜索字段回读靠它）；
      // 否则读触发器显示文本（下拉字段）。读不到再退到另一个元素，别回读成空。
      const el = elementFor(c, spec && spec.mode);
      const alt = String(spec && spec.mode) === 'input' ? triggerOf(c)
        : c.querySelector('input:not([type="hidden"]):not([disabled])');
      let v = valueOfEl(el);
      if (!v && alt && alt !== el) v = valueOfEl(alt);
      let count = 0;
      try { count = RPFiller.containersOf(d.doc).length; } catch (e) { count = 0; }
      return { display: v, value: v, fieldCount: count, label: RPFiller.displayNameOf(el || alt, c) || '' };
    }
    return { display: '', value: '', fieldCount: 0, reason: '字段已消失：' + ((spec && spec.displayName) || '') };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return;
    if (msg.type === 'RP_PROBE') {
      probe().then(sendResponse).catch((e) => sendResponse({ error: String(e && e.message) }));
      return true;
    }
    if (msg.type === 'RP_FILL') {
      fill(msg.plan || [], msg.displayMap || {}, msg.opts || {})
        .then(sendResponse)
        .catch((e) => sendResponse({ error: String(e && e.message) }));
      return true;
    }
    if (msg.type === 'RP_SCAN') {
      const scan = scanAllFrames();
      sendResponse({ rendered: scan.fields, frameScan: scan.diag, url: location.href });
      return true;
    }
    if (msg.type === 'RP_DIAG') {
      try { sendResponse(diagnose()); } catch (e) { sendResponse({ error: String(e && e.message) }); }
      return true;
    }
    // 单独选一个下拉值（手动兜底用）
    if (msg.type === 'RP_SELECT_ONE') {
      RPFiller.selectOnly(document, msg.schemaName, msg.displayName, msg.value)
        .then(sendResponse)
        .catch((e) => sendResponse({ error: String(e && e.message) }));
      return true;
    }

    /* 真人动作（CDP 可信输入）配套查询 */
    if (msg.type === 'RP_HUMAN_LOCATE') {
      humanLocate(msg).then(sendResponse).catch((e) => sendResponse({ ok: false, reason: String(e && e.message) }));
      return true;
    }
    if (msg.type === 'RP_HUMAN_OPTIONS') {
      try { sendResponse({ list: humanOptions() }); }
      catch (e) { sendResponse({ list: [], error: String(e && e.message) }); }
      return true;
    }
    if (msg.type === 'RP_HUMAN_ACTIVE') {
      try { sendResponse(humanActive()); } catch (e) { sendResponse({ text: '' }); }
      return true;
    }
    if (msg.type === 'RP_HUMAN_VERIFY') {
      try { sendResponse(humanVerify(msg)); } catch (e) { sendResponse({ display: '', fieldCount: 0, error: String(e && e.message) }); }
      return true;
    }
    if (msg.type === 'RP_HUMAN_LIST') {
      try { sendResponse({ list: humanList() }); } catch (e) { sendResponse({ list: [], error: String(e && e.message) }); }
      return true;
    }
  });
})();
