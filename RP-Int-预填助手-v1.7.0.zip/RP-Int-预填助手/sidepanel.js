/* RP Int 预填助手 — 侧边栏逻辑。 */
(function () {
  'use strict';
  const U = RPUtil, S = RPStore;
  const $ = (id) => document.getElementById(id);

  let tab = null;            // 当前标签页信息
  let cache = null;          // 探测缓存 { fields, rendered, source }
  let people = [];
  let selectedId = null;
  let seq = [];           // ①真人动作的执行顺序（可编辑，来自 settings.humanSeq）
  const filledByUs = [];     // 本次填过的字段，用于「清空我填的」

  /* ---------- 工具 ---------- */
  /** 归一化字段名：大小写、下划线、空格差异都抹平。
      用来判断「真人动作已经处理过的字段」和「计划里的字段」是不是同一个。
      不依赖探测缓存 —— 没探测过时 displayMap 是空的，靠它去重会漏。
      走 store.canonField：连「Resource ↔ It Code」这种**别名**也一起折叠，
      否则序列里叫 Resource、人员表里叫 It Code 会被当成两个字段各写一遍。 */
  function normKey(s) {
    return S.canonField(s);
  }

  /** 整数类型的值钳制：必须是非负整数、且 ≤ 上限（出厂 23）。
      非法值原样返回（交给运行时报错），不静默截断用户刚敲的字。 */
  function clampInt(v, max) {
    const s = String(v == null ? '' : v).trim();
    if (!s) return s;
    let n = Number(s);
    if (isNaN(n)) return s;
    if (!Number.isInteger(n)) n = Math.round(n);
    if (n < 0) n = 0;
    if (max != null && !isNaN(max) && n > max) n = max;
    return String(n);
  }

  /* 正文做成响应式（width:100% + flex 换行），拖宽/拖窄面板时布局自动重排。 */

  /* ---------- ⓪ 目标页面：第一次把网址填进来，之后一键打开 ---------- */
  const TARGET_URL_KEY = 'targetUrl';

  function targetUrlValue() {
    const el = $('targetUrl');
    return el ? String(el.value || '').trim() : '';
  }

  /** 载入时把上次记住的地址填回输入框 */
  async function applyTargetUrl() {
    const saved = await S.get(TARGET_URL_KEY, '');
    const el = $('targetUrl');
    if (el && saved) el.value = saved;
  }

  /** 校验并记住地址，然后交给 background 打开（newTab=false → 当前标签页） */
  async function doOpenUrl(newTab) {
    const info = $('targetInfo');
    const url = targetUrlValue();
    if (!U.isHttpUrl(url)) {
      info.innerHTML = '<span class="badge err">地址不对</span> ' +
        '请填完整地址，以 <b>http://</b> 或 <b>https://</b> 开头。';
      return;
    }
    await S.set(TARGET_URL_KEY, url);   // 记住，下次打开侧边栏就带出来
    const r = await toBackground('RP_OPEN_URL', { url: url, newTab: !!newTab });
    if (!r || r.error) {
      info.innerHTML = '<span class="badge err">打开失败</span> ' + U.escapeHtml((r && r.error) || '无响应');
      return;
    }
    info.innerHTML = '<span class="badge ok">已打开</span> ' +
      (newTab ? '新页签' : '当前页签') + ' —— ' + U.escapeHtml(url);
  }

  function toBackground(type, payload) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), (r) => {
        if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
        else resolve(r || { error: '无响应' });
      });
    });
  }

  /* 探测/诊断走 background 广播（覆盖所有 iframe）；
     填充只发 top frame，由 content script 自行遍历 iframe，避免重复填。 */
  function msg(type, payload) {
    return toBackground(type === 'RP_PROBE' ? 'RP_BROADCAST_PROBE' :
      type === 'RP_DIAG' ? 'RP_BROADCAST_DIAG' :
      type === 'RP_FILL' ? 'RP_FILL_TOP' : type, payload);
  }

  /** 把 background 聚合的多 frame 回复合并成一份探测结果 */
  function mergeReplies(r) {
    if (!r || !r.__replies) {
      const noReply = { error: (r && r.error) || '无响应' };
      if (r && r.__errors && r.__errors.length) noReply.frameErrors = r.__errors;
      if (r && r.__frameUrls) noReply.frameUrls = r.__frameUrls;
      return noReply;
    }
    const replies = r.__replies;
    const errors = r.__errors || [];
    const frameUrls = r.__frameUrls || [];
    // 一个 frame 都没回，但拿到了 frame 列表 → 注入没成功（最常见：跨域 / 未刷新页面）
    if (!replies.length) {
      const e = {
        error: 'content script 未响应',
        frameErrors: errors,
        frameUrls: frameUrls,
        frameTotal: (r.__frames || []).length
      };
      return e;
    }

    let fields = [];
    let rendered = [];
    let frameScan = [];
    let metaAttempts = [];
    let source = 'dom';
    let url = '';
    replies.forEach((rep) => {
      if (rep.fields && rep.fields.length) { fields = rep.fields; source = 'webapi'; }
      if (rep.rendered) rendered = rendered.concat(rep.rendered);
      if (rep.frameScan) frameScan = frameScan.concat(rep.frameScan);
      if (rep.metaAttempts && rep.metaAttempts.length) metaAttempts = rep.metaAttempts;
      if (rep.url && rep.url.indexOf('main.aspx') >= 0) url = rep.url;
    });
    return { fields, rendered, frameScan, metaAttempts, source, url, frameErrors: errors, frameUrls: frameUrls };
  }

  function show(el, on) { el.style.display = on ? '' : 'none'; }

  function fieldsFromCache() {
    return (cache && cache.fields && cache.fields.length)
      ? cache.fields
      : (cache && cache.rendered ? cache.rendered.map((r) => ({
          schemaName: r.schemaName, displayName: r.displayName, control: guessControl(r)
        })) : []);
  }

  /** DOM 兜底场景：按已渲染控件推断控件类别 */
  function guessControl(r) {
    if (!r) return 'text';
    if (r.type === 'checkbox') return 'boolean';
    if (r.tag === 'select') return 'optionset';
    if (r.tag === 'textarea') return 'text';
    return 'text';
  }

  function displayMap() {
    const m = {};
    fieldsFromCache().forEach((f) => { m[f.schemaName] = f.displayName; });
    return m;
  }

  /* ---------- 人员列表：Name + ItCode 直接可改 ----------
     「③ 编辑选中人员」整块已删 —— 名单里两列都能直接改，改完即存，
     省掉「选人 → 切到编辑区 → 点保存」这一趟来回，也不会出现「改了没保存」。 */
  const ITCODE_KEY = 'It Code';   // 人员表里存 ItCode 的字段名

  function itcodeOf(p) {
    if (!p || !p.fields) return '';
    const v = p.fields[ITCODE_KEY];
    return v == null ? '' : String(v);
  }

  function renderPeople() {
    const box = $('peopleList');
    const q = String($('search').value || '').trim().toLowerCase();
    const list = people.filter((p) => !q ||
      p.name.toLowerCase().indexOf(q) >= 0 ||
      itcodeOf(p).toLowerCase().indexOf(q) >= 0);
    if (!list.length) {
      box.innerHTML = '<div class="empty">' + (people.length ? '没有匹配的人员' : '还没有人员，点「新建」添加') + '</div>';
      return;
    }
    box.innerHTML = list.map((p) =>
      '<div class="p-item' + (p.id === selectedId ? ' sel' : '') + '" data-id="' + U.escapeHtml(p.id) + '">' +
        '<input type="radio" class="p-radio" name="pSel" data-pr="' + U.escapeHtml(p.id) + '"' +
          (p.id === selectedId ? ' checked' : '') + ' title="选中此人用于预填">' +
        '<input type="text" class="p-in p-name" data-pn="' + U.escapeHtml(p.id) + '" value="' +
          U.escapeHtml(p.name) + '" title="姓名（可直接改）">' +
        '<input type="text" class="p-in p-code" data-pc="' + U.escapeHtml(p.id) + '" value="' +
          U.escapeHtml(itcodeOf(p)) + '" placeholder="ItCode" title="ItCode（填进 Resource 字段，可直接改）">' +
        '<button class="del" data-del="' + U.escapeHtml(p.id) + '" style="padding:1px 6px;font-size:10px">删</button>' +
      '</div>').join('');
  }

  function currentPerson() {
    return people.find((p) => p.id === selectedId) || null;
  }

  /** 选中的人员 → 把他的 ItCode 同步进「④ 真人动作」第 4 步 Resource 的录入框。
      选人即等于选 Resource 取值，避免「选了人但 Resource 还是旧值」的脱节。
      normKey 走别名折叠：'Resource' 与 'It Code' 都归到 'itcode'，所以比对要用 normKey 形式。 */
  async function syncResourceFromSelected() {
    const idx = seq.findIndex((s) => normKey(s.name) === normKey('Resource'));
    if (idx < 0) return;
    const p = currentPerson();
    seq[idx].value = p ? itcodeOf(p) : '';
    renderSeq();
    await S.saveSettings({ humanSeq: seq });
  }

  function selectPerson(id) {
    selectedId = id;
    renderPeople();
    syncResourceFromSelected();
  }

  function controlOfSchema(schema) {
    const f = fieldsFromCache().find((x) => x.schemaName === schema);
    return f ? f.control : 'text';
  }

  /* ---------- ①真人动作：触发顺序（可编辑） ---------- */
  const CTL_LABEL = { optionset: '下拉', lookup: '搜索', text: '文本', integer: '整数', number: '数字' };

  /** 重复步骤：同名字段出现多次时，标出「非最后一次」的那些（即该删的第一遍） */
  function dupSet() {
    const last = {};
    const dup = {};
    seq.forEach((s, i) => { const k = normKey(s.name); if (k) last[k] = i; });
    seq.forEach((s, i) => { const k = normKey(s.name); if (k && last[k] !== i) dup[i] = true; });
    return dup;
  }

  function renderSeq() {
    const box = $('seqList');
    if (!seq.length) {
      box.innerHTML = '<div class="muted" style="padding:6px 0">没有步骤。点「加一步」添加。</div>';
      return;
    }
    const dup = dupSet();
    box.innerHTML = seq.map((s, i) =>
      '<div class="field-row seq-row' + (dup[i] ? ' dup' : '') + '"' +
        (dup[i] ? ' title="与后面的步骤重复（同一个字段会被录入两遍）"' : '') + '>' +
        '<span class="seq-no">' + (i + 1) + '</span>' +
        '<input type="text" data-sq-name="' + i + '" value="' + U.escapeHtml(s.name || '') +
          '" placeholder="字段名">' +
        '<input type="text" data-sq-val="' + i + '" value="' + U.escapeHtml(s.value || '') +
          '" placeholder="' + (s.control === 'integer' ? '整数 ≤' + (s.max != null ? s.max : 23) : '要选择的值') + '">' +
        (s.control === 'integer' ? '<span class="seq-max" title="整数上限（超过会被钳到该值）">≤' + (s.max != null ? s.max : 23) + '</span>' : '') +
        '<select data-sq-ctl="' + i + '" class="stage-sel" title="控件类型">' +
          Object.keys(CTL_LABEL).map((c) =>
            '<option value="' + c + '"' + (s.control === c ? ' selected' : '') + '>' +
            CTL_LABEL[c] + '</option>').join('') +
        '</select>' +
        '<button class="mv" data-sq-up="' + i + '" title="上移"' + (i === 0 ? ' disabled' : '') + '>↑</button>' +
        '<button class="mv" data-sq-dn="' + i + '" title="下移"' +
          (i === seq.length - 1 ? ' disabled' : '') + '>↓</button>' +
        '<button class="mv" data-sq-rm="' + i + '" title="删除">×</button>' +
      '</div>').join('');
  }

  /** 从 DOM 收集当前序列（改完即存，用户不用记着点保存） */
  async function collectSeq() {
    const out = [];
    $('seqList').querySelectorAll('.seq-row').forEach((row) => {
      const n = row.querySelector('input[data-sq-name]');
      if (!n) return;
      const v = row.querySelector('input[data-sq-val]');
      const c = row.querySelector('select[data-sq-ctl]');
      const name = String(n.value || '').trim();
      if (!name) return;
      // 启用勾选框已去掉：序列里的每一步都会执行
      const ctl = c ? c.value : 'optionset';
      const rawVal = v ? String(v.value || '').trim() : '';
      const outVal = ctl === 'integer' ? clampInt(rawVal, 23) : rawVal;
      out.push({
        name: name,
        value: outVal,
        control: ctl,
        max: ctl === 'integer' ? 23 : undefined,
        enabled: true
      });
    });
    seq = out;
    await S.saveSettings({ humanSeq: out });
    const dups = Object.keys(dupSet()).map(Number);
    $('seqInfo').innerHTML = '<span class="badge ok">已保存</span> 共 ' + out.length + ' 步' +
      (dups.length
        ? '<br><span class="badge wait">有 ' + dups.length + ' 个重复步骤</span> ' +
          U.escapeHtml(dups.map((i) => seq[i].name).join('、')) +
          '　同一个字段会被录入两遍，点「去掉重复」删掉前面的'
        : '');
  }

  /** 去掉重复步骤：保留每组最后一次出现的，删掉前面的（= 用户说的「把第一遍删掉」） */
  async function dedupSeq() {
    const drop = dupSet();
    const keep = seq.filter((s, i) => !drop[i]);
    const removed = seq.length - keep.length;
    if (!removed) {
      $('seqInfo').innerHTML = '<span class="badge ok">没有重复步骤</span>';
      return;
    }
    seq = keep;
    renderSeq();
    await S.saveSettings({ humanSeq: seq });
    $('seqInfo').innerHTML = '<span class="badge ok">已去掉 ' + removed +
      ' 个重复步骤</span> 保留每组最后一次出现的';
  }

  /** 批量导入 12 个月数值：贴两行（表头 26-Oct 26-Nov… / 数值 1 1 …），
      按月份对号入座写进同名步骤 —— 与列顺序无关，列顺序可以乱。 */
  async function doImportMonths() {
    const info = $('monthImportInfo');
    await collectSeq();   // 先把界面上当前的编辑收进来，避免覆盖用户刚改的值
    const parsed = U.parseMonthImport(U.parseTable(String($('monthTsv').value || '')));
    if (!parsed.pairs.length) {
      info.innerHTML = '<span class="badge err">没识别出月份</span> ' +
        '需要两行：第一行月份表头（如 26-Oct、26-Nov），第二行数值（1、1…）。月份用英文 Jan…Dec。';
      return;
    }
    const applied = [], missing = [];
    parsed.pairs.forEach((p) => {
      const i = seq.findIndex((s) => U.monthKey(s.name) === p.key);
      if (i < 0) { missing.push(p.header); return; }
      seq[i].value = p.value;
      applied.push(seq[i].name + '=' + (p.value === '' ? '(清空)' : p.value));
    });
    renderSeq();
    await S.saveSettings({ humanSeq: seq });
    info.innerHTML = '<span class="badge ok">已导入 ' + applied.length + ' 个月份</span> ' +
      U.escapeHtml(applied.join('、')) +
      (missing.length
        ? '<br><span class="badge wait">顺序里没有这些月份</span> ' +
          U.escapeHtml(missing.join('、')) + '　先在下面「加一步」用同名月份建好步骤'
        : '');
  }

  /** 组装真人动作的执行清单：顺序 = 上面的列表（全部步骤，含无值的）。
      无值的步骤（Resource 之外的空步骤、12 个月）交给 runSequence 标「跳过」，
      仍显示在回执里 —— 月份等人员数据字段由后续普通填充接手，不会重复写。 */
  function humanSeqSpecs(plan) {
    return seq
      .filter((s) => s.enabled !== false && String(s.name || '').trim())
      .map((s) => {
        const name = String(s.name).trim();
        return {
          schemaName: name, displayName: name,
          value: String(s.value || '').trim(),
          control: s.control || 'optionset'
        };
      });
  }

  /* ---------- 探测 ---------- */
  function showFrameScan(scan) {
    if (!scan || !scan.length) { show($('frameBox'), false); return; }
    show($('frameBox'), true);
    $('frameBody').innerHTML = scan.map((f) =>
      '<tr><th>' + U.escapeHtml(f.frame) + '</th>' +
      '<td class="muted">' + U.escapeHtml(f.found) + ' 个字段</td>' +
      '<td class="muted">' + U.escapeHtml(String(f.url || '').slice(0, 40)) + '</td></tr>'
    ).join('');
  }

  /** 把「0 字段 / 无响应」的原因分层讲清楚 */
  function explainEmpty(r) {
    const lines = [];

    // 情况 A：content script 一个 frame 都没响应 → 注入失败
    if (r.frameErrors && r.frameErrors.length) {
      const total = r.frameTotal != null ? r.frameTotal : r.frameErrors.length;
      lines.push('<b>脚本未注入到任何 frame</b>（共 ' + total + ' 个 frame，0 个响应）');
      lines.push('');

      // 逐 frame 列出 URL —— 判断是不是跨域 iframe
      if (r.frameUrls && r.frameUrls.length) {
        lines.push('页面 frame 清单：');
        r.frameUrls.slice(0, 12).forEach((f) => {
          const sameHost = f.url.indexOf('lenovo-ironman-prod') >= 0;
          const u = f.url || '(空)';
          lines.push('&nbsp;&nbsp;<span class="badge ' + (sameHost ? 'ok' : 'wait') + '">' +
            (sameHost ? '同域' : '跨域?') + '</span> #' + f.frameId + ' ' +
            U.escapeHtml(u.length > 70 ? u.slice(0, 70) + '…' : u));
        });
      }

      const errs = {};
      (r.frameErrors || []).forEach((e) => {
        const k = String(e.error || '').replace(/\d+/g, '#');
        errs[k] = (errs[k] || 0) + 1;
      });
      lines.push('');
      lines.push('失败原因：' + Object.keys(errs).map((k) =>
        U.escapeHtml(k) + ' × ' + errs[k]).join('；'));

      lines.push('');
      if (/Cannot access|extension manifest|Missing host permission/i.test(
        Object.keys(errs).join(' '))) {
        lines.push('<b>这是跨域 frame</b>：目标系统 把表单放在别的域名下，插件没权限注入。' +
          '需要在 chrome://extensions 里给该域名加权限。');
      } else {
        lines.push('<b>最可能的原因</b>：扩展刚更新，页面还是旧的。' +
          '请在 目标系统 页面按 <b>F5</b> 刷新，或点下面的「强制注入脚本」。');
      }
      return lines.join('<br>');
    }

    if (r.error) {
      lines.push('<b>页面无响应</b>：' + U.escapeHtml(r.error));
      lines.push('请在 目标系统 页面按 F5 刷新，再点一次探测；或点「强制注入脚本」。');
      return lines.join('<br>');
    }

    const frames = r.frameScan || [];
    const totalRendered = (r.rendered || []).length;

    lines.push('<b>脚本已注入，但两条通道都没拿到字段</b>：');
    lines.push('① Web API 元数据：' + (r.source === 'webapi'
      ? '<span class="badge ok">成功</span>'
      : '失败 —— ' + (r.metaAttempts && r.metaAttempts[0]
        ? U.escapeHtml(r.metaAttempts[0].error) + (r.metaAttempts[0].status === 403 ? '（权限不足）' : '')
        : '未知原因')));

    if (frames.length) {
      lines.push('② 各 frame 控件数：' + frames.map((f) => f.frame + ' → ' + f.found).join('，'));
    }
    if (totalRendered === 0) {
      lines.push('<b>原因</b>：表单还没渲染完。请等字段都显示出来再点探测。');
    } else {
      lines.push('已扫到 ' + totalRendered + ' 个控件但没归类成字段 —— 点「排查：导出页面结构」把结果发我。');
    }
    return lines.join('<br>');
  }

  /** 强制注入：静态注入失败时的兜底 */
  async function doInject() {
    const btn = $('btnInject');
    btn.disabled = true; btn.textContent = '注入中…';
    const r = await toBackground('RP_INJECT');
    btn.disabled = false; btn.textContent = '强制注入脚本';

    if (!r || r.error) {
      $('probeInfo').innerHTML = '<span class="badge err">注入失败</span> ' + U.escapeHtml(r && r.error || '');
      return;
    }
    $('probeInfo').innerHTML = '<span class="badge ' + (r.injected ? 'ok' : 'err') + '">注入 ' +
      r.injected + '/' + r.total + '</span><br>' +
      (r.results || []).filter((x) => !x.ok).slice(0, 6).map((x) =>
        '#' + x.frameId + ' ' + U.escapeHtml(String(x.error).slice(0, 90))).join('<br>') +
      (r.injected ? '<br>注入完成，现在点「探测字段」。' : '');
  }

  async function doProbe() {
    const btn = $('btnProbe');
    btn.disabled = true; btn.textContent = '探测中…';
    const raw = await msg('RP_PROBE');
    btn.disabled = false; btn.textContent = '探测字段';

    const r = mergeReplies(raw);
    if (r.error) { $('probeInfo').innerHTML = explainEmpty(r); show($('btnInject'), true); return; }

    cache = { fields: r.fields || [], rendered: r.rendered || [], source: r.source };
    await S.saveCache(Object.assign({ at: Date.now(), url: r.url }, cache));

    const n = (r.fields || []).length;
    const nd = (r.rendered || []).length;
    showFrameScan(r.frameScan);

    if (n === 0 && nd === 0) {
      $('probeInfo').innerHTML = '<span class="badge err">0 个字段</span><br>' + explainEmpty(r);
      show($('fieldBox'), false);
      show($('btnInject'), true);
      return;
    }
    show($('btnInject'), false);

    $('probeInfo').innerHTML = '<span class="badge ok">' +
      (r.source === 'webapi' ? '元数据' : 'DOM') + '</span> ' +
      '识别字段 <b>' + (n || nd) + '</b> 个' +
      (n === 0 ? '（元数据接口不可用，已降级为页面扫描）' : '');

    show($('fieldBox'), true);
    $('fieldCount').textContent = n || nd;
    $('fieldBody').innerHTML = (n ? r.fields : r.rendered).map((f) =>
      '<tr><th title="' + U.escapeHtml(f.schemaName) + '">' +
      U.escapeHtml(f.displayName || '(无标签)') + '</th>' +
      '<td class="muted">' + U.escapeHtml(f.schemaName || '—') + '</td>' +
      '<td>' + U.escapeHtml(f.control || f.tag || '') +
      (f.required ? ' <span class="badge wait">必填</span>' : '') + '</td></tr>'
    ).join('');
  }

  async function doScan() {
    const raw = await msg('RP_SCAN');
    if (raw && raw.error) { $('probeInfo').innerHTML = '<span class="badge err">失败</span> ' + U.escapeHtml(raw.error); return; }
    if (!raw || !raw.rendered) {
      $('probeInfo').innerHTML = '<span class="badge err">0 个字段</span><br>' +
        explainEmpty({ error: raw && raw.error });
      return;
    }
    cache = { fields: cache ? cache.fields : [], rendered: raw.rendered, source: 'dom' };
    showFrameScan(raw.frameScan);
    if (!raw.rendered.length) {
      $('probeInfo').innerHTML = '<span class="badge err">0 个控件</span><br>' +
        '页面里没找到任何可填控件。表单可能还没渲染完，或渲染在跨域 iframe 里（插件读不到）。' +
        '请等页面加载完再试，或点「排查：导出页面结构」。';
      return;
    }
    show($('fieldBox'), true);
    $('fieldCount').textContent = raw.rendered.length;
    $('fieldBody').innerHTML = raw.rendered.map((f) =>
      '<tr><th>' + U.escapeHtml(f.displayName || '(无标签)') + '</th>' +
      '<td class="muted" title="' + U.escapeHtml((f.hints || []).join(' / ')) + '">' +
      U.escapeHtml(f.schemaName || '—') + '</td>' +
      '<td class="muted">' + U.escapeHtml([f.tag, f.type, f.role].filter(Boolean).join(' ')) +
      (f.frame ? '<br><span class="muted">' + U.escapeHtml(f.frame) + '</span>' : '') + '</td></tr>').join('');
    $('probeInfo').innerHTML = '<span class="badge wait">DOM</span> 页面已渲染 ' +
      raw.rendered.length + ' 个控件';
  }

  /* ---------- 页面结构诊断 ---------- */
  let lastDiag = null;
  async function doDiag() {
    const btn = $('btnDiag');
    btn.disabled = true; btn.textContent = '采集页面结构…';
    const raw = await msg('RP_DIAG');
    btn.disabled = false; btn.textContent = '排查：导出页面结构';

    if (raw && raw.error) { $('probeInfo').innerHTML = '<span class="badge err">失败</span> ' + U.escapeHtml(raw.error); return; }
    lastDiag = raw;
    show($('btnCopyDiag'), true);

    const t = (raw && raw.top) || {};
    const frames = (raw && raw.frames) || [];
    const lines = [];
    lines.push('<b>主文档</b>：iframe ' + (t.iframeCount || 0) + ' 个，控件 ' +
      (t.controlCount || 0) + ' 个，label ' + (t.labelCount || 0) + ' 个');
    if (t.classHits && t.classHits.length) {
      lines.push('命中样式：' + t.classHits.map((c) => c.pattern + '×' + c.count).join('，'));
    }
    if (t.labelTexts && t.labelTexts.length) {
      lines.push('页面标签：' + U.escapeHtml(t.labelTexts.slice(0, 12).join(' / ')));
    }
    frames.forEach((f) => {
      if (f.reachable) {
        lines.push('<b>' + U.escapeHtml(f.frame) + '</b>（可访问）：控件 ' +
          (f.inner.controlCount || 0) + ' 个，label ' + (f.inner.labelCount || 0) + ' 个' +
          (f.inner.classHits && f.inner.classHits.length
            ? '<br>&nbsp;&nbsp;样式：' + U.escapeHtml(f.inner.classHits.map((c) => c.pattern + '×' + c.count).join('，'))
            : ''));
      } else {
        lines.push('<b>' + U.escapeHtml(f.frame) + '</b>：跨域，无法访问' +
          (f.error ? '（' + U.escapeHtml(f.error) + '）' : ''));
      }
    });
    $('probeInfo').innerHTML = lines.join('<br>') +
      '<br><b>点「复制诊断结果」把完整结构（含控件 HTML 片段）发给我。</b>';
  }

  $('btnCopyDiag').addEventListener('click', async () => {
    if (!lastDiag) return;
    const txt = JSON.stringify(lastDiag, null, 2);
    try {
      await navigator.clipboard.writeText(txt);
      $('btnCopyDiag').textContent = '已复制 ✓';
      setTimeout(() => { $('btnCopyDiag').textContent = '复制诊断结果'; }, 1600);
    } catch (e) {
      // 剪贴板 API 不可用时降级为下载
      const blob = new Blob([txt], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'rp-diag.json';
      a.click();
      URL.revokeObjectURL(a.href);
    }
  });

  /* ---------- 搜索字段（Lookup） ---------- */
  /** 搜索字段名单不再手工维护 —— 「④ 真人动作：触发顺序」里类型=搜索 的步骤就是搜索字段。
      （DOM 降级探测认不出 Lookup，以前靠用户手输，现在序列自带 control，自动推导。） */
  function lookupNames() {
    const out = [];
    seq.forEach((s) => {
      if (!s || s.enabled === false) return;
      if (String(s.control || '').toLowerCase() !== 'lookup') return;
      const n = String(s.name || '').trim();
      if (n && out.indexOf(n) < 0) out.push(n);
    });
    return out;
  }

  function lookupSpecsFromPlan(plan) {
    const known = fieldsFromCache();
    return plan
      .filter((x) => x.control === 'lookup' && String(x.value || '').trim() !== '')
      .map((x) => {
        const f = known.find((y) => y.schemaName === x.schemaName);
        return {
          schemaName: x.schemaName,
          displayName: (f && f.displayName) || x.schemaName,
          value: String(x.value).trim()
        };
      });
  }

  /* ---------- 真人动作（可信输入） ----------
     执行清单不再从默认值推导：「④ 默认值设置 → ①真人动作：触发顺序」是唯一来源，
     见上面的 renderSeq / collectSeq / humanSeqSpecs。 */

  /* 步骤回执：明细挂在页面底部的 #traceSection（默认折叠），每次运行会更新它上方的 overview。
     append=true 表示同一轮里追加（如搜索字段那段），overview 要累计、不能被后一段覆盖。 */
  let traceAll = [];
  function renderHumanTrace(results, append) {
    if (!append) traceAll = [];
    traceAll = traceAll.concat(results || []);
    const rows = [];
    (results || []).forEach((r) => {
      // 值为空的步骤是「跳过」，不是「已选中」；否则 12 个空月份看着像填成功了。
      const badge = !r.ok
        ? '<span class="badge err">失败</span>'
        : (r.skipped ? '<span class="badge wait">跳过</span>' : '<span class="badge ok">已选中</span>');
      rows.push('<div class="r"><span>' + badge + '</span>' +
        '<span class="rs">' + (r.order ? '<span class="muted">' + r.order + '.</span> ' : '') +
        U.escapeHtml(r.label || '') +
        (r.skipped ? '' : ' ← <b>' + U.escapeHtml(String(r.value || '')) + '</b>') +
        (r.picked ? '<br><span class="muted">选中了：' + U.escapeHtml(r.picked) + '</span>' : '') +
        (r.expanded ? '<br><span class="muted">表单已展开（字段 ' + r.fieldBefore + ' → ' + r.fieldAfter + '）</span>' : '') +
        (r.display ? '<br><span class="muted">控件现在显示：' + U.escapeHtml(r.display) + '</span>' : '') +
        (r.reason ? '<br><span class="muted">' + U.escapeHtml(r.reason) + '</span>' : '') +
        '</span></div>');
      (r.steps || []).forEach((s) => {
        rows.push('<div class="r" style="padding-left:14px"><span class="muted">·</span>' +
          '<span class="rs muted">' + U.escapeHtml(s.step) + '　' +
          U.escapeHtml(stepBrief(s)) + '</span></div>');
      });
    });
    const html = rows.join('');
    if (append) $('humanTrace').insertAdjacentHTML('beforeend', html);
    else $('humanTrace').innerHTML = html;
    updateTraceOverview();
  }

  /** overview：折叠时唯一可见的汇总 —— 共几步 / 成功 / 跳过 / 失败，并列出失败步骤名。 */
  function traceOverviewHtml(s) {
    if (!s || !s.total) return '暂无执行记录';
    const bits = ['共 ' + s.total + ' 步', '成功 ' + s.ok];
    if (s.skip) bits.push('跳过 ' + s.skip);
    if (s.fail) bits.push('失败 ' + s.fail);
    let html = (s.fail
      ? '<span class="badge err">有失败</span>'
      : '<span class="badge ok">全部成功</span>') + ' ' + bits.join(' · ');
    if (s.fail && s.failNames && s.failNames.length) {
      html += '<br><span class="muted">失败步骤：' + U.escapeHtml(s.failNames.join('、')) + '</span>';
    }
    return html;
  }
  function updateTraceOverview() {
    const el = $('traceOverview');
    if (el) el.innerHTML = traceOverviewHtml(U.summarizeTrace(traceAll));
  }

  /* 「步骤回执」底部面板：toggle 开关控制展开/收起，默认 collapsed（只显示 overview）。 */
  let traceVisible = false;
  function applyTraceVisible() {
    const box = $('humanTrace');
    const btn = $('btnTraceToggle');
    if (box) box.style.display = traceVisible ? '' : 'none';
    if (btn) btn.textContent = traceVisible ? '▾ 收起步骤回执' : '▸ 展开步骤回执';
  }

  /** 「列出下拉」改成可开可关的按钮：点一下列出页面所有下拉字段（核对真实字段名），
      再点一次收起隐藏。输出单独放到 #humanListBox，不占用真人动作回执区。 */
  let humanListVisible = false;
  async function doHumanList() {
    const btn = $('btnHumanList');
    const box = $('humanListBox');
    if (humanListVisible) {
      humanListVisible = false;
      box.style.display = 'none';
      box.innerHTML = '';
      btn.textContent = '列出下拉';
      return;
    }
    btn.disabled = true; btn.textContent = '读取中…';
    const r = await toBackground('RP_HUMAN_LIST', {});
    btn.disabled = false;
    const list = (r && r.list) || [];
    if (!list.length) {
      humanListVisible = false;
      btn.textContent = '列出下拉';
      $('humanInfo').innerHTML = '<span class="badge err">没读到下拉</span> ' +
        U.escapeHtml((r && r.error) || '页面里没找到 combobox 控件，请确认表单已加载完。');
      return;
    }
    box.style.display = '';
    box.innerHTML = '<b>页面上的下拉字段（' + list.length + ' 个）</b> —— ' +
      '用这里的「字段名」配默认值最准：' +
      '<table class="kv"><tbody>' + list.map((f) =>
        '<tr><th>' + U.escapeHtml(f.label || '(无标签)') + '</th>' +
        '<td class="muted">' + U.escapeHtml(f.schema || '—') + '</td>' +
        '<td>' + U.escapeHtml(f.display || '（空）') + '</td></tr>').join('') + '</tbody></table>' +
      '<div class="muted" style="margin-top:4px">左列=页面标签，中列=解析出的 schema 名，右列=当前值。</div>';
    humanListVisible = true;
    btn.textContent = '收起下拉';
  }

  function stepBrief(s) {
    if (s.rect) return '(' + s.rect.x + ',' + s.rect.y + ')';
    if (s.texts) return String(s.texts.slice(0, 8).join(' / '));
    if (s.text) return String(s.text);
    if (s.display != null) return String(s.display) + (s.ok ? ' ✓' : ' ✗');
    if (s.count != null) return s.count + ' 项';
    if (s.label) return String(s.label);
    if (s.reason) return String(s.reason);
    if (s.fieldAfter != null) return '字段 ' + s.fieldBefore + ' → ' + s.fieldAfter;
    return '';
  }

  async function doHumanPick(specsOverride) {
    const p = currentPerson();
    const plan = p ? S.applyDefaults(p, {}, true, lookupNames()) : [];
    const specs = specsOverride || humanSeqSpecs(plan);
    if (!specs.length) {
      $('humanInfo').innerHTML = '<span class="badge wait">没有可执行的步骤</span> ' +
        '请到「④ 默认值设置 → ①真人动作：触发顺序」加一步，并填要选择的值（如 Source Type = Internal）。';
      return null;
    }
    const btn = $('btnFill');
    btn.disabled = true;
    btn.textContent = '真人动作执行中…（共 ' + specs.length + ' 步，看页面）';
    const r = await toBackground('RP_HUMAN_PICK', { specs: specs });
    btn.disabled = false;
    btn.textContent = '执行预填';

    if (!r || r.error) {
      $('humanInfo').innerHTML = '<span class="badge err">失败</span> ' + U.escapeHtml(r && r.error || '');
      return null;
    }
    renderHumanTrace(r.results);
    const names = specs.map((s) => s.displayName + '=' + s.value).join(' → ');
    $('humanInfo').innerHTML =
      '<span class="badge ' + (r.failed ? 'wait' : 'ok') + '">' + r.ok + '/' + r.total + ' 选中</span> ' +
      U.escapeHtml(names) +
      (r.expanded
        ? '<br><b>表单已展开新字段区</b> —— 现在点「填入表单」填人员信息。'
        : '<br><span class="muted">表单字段数没变化。若页面上其实展开了，直接点「填入表单」继续；' +
          '若确实没反应，说明该字段不是联动触发字段，请换一个字段试。</span>');
    return r;
  }

  /* ---------- 填充 ---------- */
  async function doFill() {
    const p = currentPerson();
    if (!p) { $('fillInfo').innerHTML = '<span class="badge err">未选人员</span> 请先选择或新建人员'; return; }
    const plan0 = S.applyDefaults(p, {}, true, lookupNames());
    if (!plan0.length) { $('fillInfo').innerHTML = '<span class="badge err">无内容</span> 该人员没有字段值'; return; }
    /* 搜索字段不交给合成写入：合成事件写进搜索框不会触发搜索，只会把关键字
       当纯文本留在框里，可信输入再输一遍就叠成两遍。 */
    const isLookup = (x) => String(x.control || '').toLowerCase() === 'lookup';
    let plan = plan0.filter((x) => !isLookup(x));
    let lookupPlan = plan0.filter(isLookup);
    let split = S.splitStages(plan);
    const btn = $('btnFill');
    btn.disabled = true;

    /* 勾选了「先用真人动作」：按「④ 默认值设置 → ①真人动作：触发顺序」自上而下执行。
       顺序不是从默认值推导出来的 —— 目标系统 字段有先后依赖，顺序错了选不到值。 */
    let human = null;
    let humanLine = '';
    // 合并按钮：始终以真人动作为主线 —— 先按「④ 真人动作：触发顺序」选触发字段，再填人员字段
    const seqSpecs = humanSeqSpecs(plan0);
    if (seqSpecs.length) {
      btn.textContent = '①真人动作（' + seqSpecs.length + ' 步）…';
      human = await doHumanPick(seqSpecs);
      if (!human || !human.ok) {
        btn.disabled = false; btn.textContent = '执行预填';
        $('fillInfo').innerHTML = '<span class="badge err">真人动作一步都没成功</span> ' +
          '已停止填充，避免写入到未展开的表单上。' +
          '<br>看上面的步骤回执定位原因；确认页面其实已展开的话，可以取消勾选「先用真人动作」直接填入。';
        return;
      }
      // 真人动作已处理的字段，后续一律不再写入（否则就是「录入两遍」）。
      // 匹配用归一化键：大小写/下划线/空格差异都不影响，且不依赖探测缓存。
      const disp = displayMap();
      // 只把「真人动作真正执行成功」的字段算作已填：跳过（值为空）的步骤不算，
      // 否则 12 个月这类无值步骤会被误判为已填，普通填充就不再接手它们。
      const done = (human.results || []).filter((x) => x.ok && !x.skipped)
        .map((x) => normKey(x.label || ''));
      const isDone = (x) => done.indexOf(normKey(x.schemaName)) >= 0 ||
        done.indexOf(normKey(disp[x.schemaName] || '')) >= 0;
      plan = plan.filter((x) => !isDone(x));
      lookupPlan = lookupPlan.filter((x) => !isDone(x));
      split = S.splitStages(plan);
      if (!plan.length && !lookupPlan.length) {
        btn.disabled = false; btn.textContent = '执行预填';
        $('fillInfo').innerHTML =
          '<span class="badge ok">真人动作已完成</span> ' + human.ok + '/' + human.total +
          ' 步，计划里的字段都已由真人动作填好，无需再填。';
        return;
      }
      humanLine = '<span class="badge ' + (human.failed ? 'wait' : 'ok') + '">真人动作 ' +
        human.ok + '/' + human.total + '</span> ' +
        U.escapeHtml((human.results || []).map((x) => x.label + '=' + (x.picked || x.value)).join(' → ')) +
        (human.failed ? '<br><span class="badge wait">有 ' + human.failed + ' 步失败</span> 见上方步骤回执' : '');
      // 等 目标系统 把新字段区渲染出来
      await new Promise((r) => setTimeout(r, 900));
    }

    btn.textContent = split.hasTwoStage ? '①触发填入中…' : '填入中…';

    const opts = split.hasTwoStage ? { twoStage: true, timeout: 10000 } : {};
    let r = { results: [], needConfirm: [] };
    if (plan.length) {
      const rr = await msg('RP_FILL', { plan: plan, displayMap: displayMap(), opts: opts });
      if (rr) r = rr;
    }
    // 搜索字段只走可信输入（合成写入已禁用，见 filler.fillLookup）
    const lookups = lookupSpecsFromPlan(lookupPlan);
    let lookupLine = '';
    if ($('lookupAuto').checked && lookups.length && !(r && r.error)) {
      btn.textContent = '搜索字段选结果…';
      const lr = await toBackground('RP_HUMAN_LOOKUP', { specs: lookups });
      if (lr && lr.results) {
        renderHumanTrace(lr.results, true);
        const names = lr.results.map((x) => x.label + ' → ' + (x.picked || x.value)).join('，');
        lookupLine = '<span class="badge ' + (lr.failed ? 'wait' : 'ok') + '">搜索字段 ' +
          lr.ok + '/' + lr.total + '</span> ' + U.escapeHtml(names);
        // 自动选中的字段从「需手动点选」里去掉
        const done = lr.results.filter((x) => x.ok).map((x) => String(x.label || ''));
        if (r.needConfirm) r.needConfirm = r.needConfirm.filter((s) => done.indexOf(s) < 0);
      }
    } else if (lookups.length) {
      // 合成写入已禁用，不勾选就没人处理这两个字段 —— 明确说出来，别静默漏填
      const names = lookups.map((x) => x.displayName || x.schemaName);
      lookupLine = '<span class="badge wait">搜索字段未处理</span> ' + U.escapeHtml(names.join('、')) +
        '　请勾选「自动点选第一条结果」，或在页面上手动点选';
      r.needConfirm = (r.needConfirm || []).concat(names);
    }
    btn.disabled = false; btn.textContent = '执行预填';

    if (!r || r.error) { $('fillInfo').innerHTML = '<span class="badge err">失败</span> ' + U.escapeHtml(r.error || ''); return; }
    filledByUs.length = 0;
    (r.results || []).forEach((x) => { if (x.ok) filledByUs.push(x.schemaName); });

    // 两阶段的过程说明
    const lines = [];
    if (humanLine) lines.push(humanLine);
    const s1 = (r.results || []).filter((x) => x.stage === 1);
    const s2 = (r.results || []).filter((x) => x.stage !== 1);
    if (split.hasTwoStage) {
      const s1ok = s1.filter((x) => x.ok).length;
      lines.push('第①步 触发字段 ' + s1ok + '/' + s1.length + ' ✓');
      if (r.wait) {
        lines.push(r.wait.ok
          ? '　表单已展开（字段数 ' + r.baseline + ' → ' + r.after + '）'
          : '<span class="badge wait">未展开</span> ' + U.escapeHtml(r.wait.reason || ''));
      }
      lines.push('第②步 人员字段 ' + s2.filter((x) => x.ok).length + '/' + s2.length);
    }
    lines.push('<span class="badge ' + (r.failed ? 'wait' : 'ok') + '">' +
      (r.failed ? '部分成功' : '全部成功') + '</span> 共 ' + r.ok + '/' + r.total +
      (r.needConfirm && r.needConfirm.length
        ? '，需手动点选：' + U.escapeHtml(r.needConfirm.join('、')) : ''));
    if (lookupLine) lines.push(lookupLine);
    $('fillInfo').innerHTML = lines.join('<br>');

    $('resList').innerHTML = (r.results || []).map((x) => {
      const detail = x.reason || x.note || '';
      const extra = (x.available && x.available.length)
        ? '可选：' + x.available.join(' / ') : '';
      const shown = x.shown ? '　当前显示：' + x.shown : '';
      return '<div class="r"><span class="badge ' + (x.ok ? 'ok' : 'err') + '">' + (x.ok ? 'OK' : '失败') + '</span>' +
        (x.stage === 1 ? '<span class="badge wait" style="font-size:9.5px">触发</span>' : '') +
        '<span class="rs" title="' + U.escapeHtml(detail + shown) + '">' +
        U.escapeHtml(x.displayName || x.schemaName) + ' ← ' + U.escapeHtml(String(x.value)) +
        (extra || shown ? '<br><span class="muted">' + U.escapeHtml(extra + shown) + '</span>' : '') +
        '</span>' +
        '<span class="muted">' + U.escapeHtml(x.from === 'default' ? '默认' : '人员') + '</span></div>';
    }).join('');
  }

  async function doClear() {
    if (!filledByUs.length) { $('fillInfo').innerHTML = '<span class="badge wait">无需清空</span> 本次会话还没填过'; return; }
    const plan = filledByUs.map((s) => ({ schemaName: s, control: controlOfSchema(s), value: '', from: 'clear' }));
    const r = await msg('RP_FILL', { plan: plan, displayMap: displayMap() });
    if (r && !r.error) {
      filledByUs.length = 0;
      $('fillInfo').innerHTML = '<span class="badge ok">已清空</span> 清掉 ' + r.ok + ' 个字段';
    }
  }

  /* ---------- 导入 / 导出 ---------- */
  async function doImport() {
    const rows = U.rowsToObjects(U.parseTable($('tsv').value));
    if (!rows.length) { alert('没有解析到数据。请确认第一行是表头，且包含「姓名」列。'); return; }
    let n = 0;
    for (const row of rows) {
      const name = row['姓名'] || row['name_label'] || row['name'] || '';
      if (!String(name).trim()) continue;
      const fields = {};
      Object.keys(row).forEach((k) => {
        if (k === '姓名' || k === 'name_label') return;
        const v = String(row[k] || '').trim();
        if (v === '') return;
        // ItCode 列：无论写成 ItCode / It Code / itcode / Resource，都归到统一的 ITCODE_KEY，
        // 否则 itcodeOf() 读不到（它只认 ITCODE_KEY = 'It Code'）。
        fields[S.normKey(k) === S.normKey(ITCODE_KEY) ? ITCODE_KEY : k] = v;
      });
      const exist = people.find((p) => U.eq(p.name, name));
      if (exist) {
        Object.assign(exist.fields, fields);
        await S.upsertPerson(exist);
      } else {
        await S.upsertPerson({ name: name, fields: fields });
      }
      n++;
    }
    people = await S.getPeople();
    $('tsv').value = '';
    renderPeople();
    $('probeInfo').innerHTML = '<span class="badge ok">导入完成</span> 共 ' + n + ' 位人员';
  }

  function doExport() {
    const p = currentPerson();
    if (!p) { alert('请先选中一位人员。'); return; }
    const keys = Object.keys(p.fields);
    const head = ['姓名'].concat(keys);
    const line = [p.name].concat(keys.map((k) => p.fields[k]));
    $('tsv').value = head.join('\t') + '\n' + line.join('\t');
    $('tsv').parentElement.open = true;
  }

  /* 手动选触发字段（联动兜底）功能已移除：合并按钮默认先真人动作选触发字段，无需再手工补。 */

  /* ---------- 初始化 ---------- */
  async function init() {
    tab = await toBackground('RP_TAB_INFO');
    if (tab && tab.isTarget) {
      $('tabInfo').innerHTML = '<span class="badge ok">已连接</span> ' + U.escapeHtml(tab.title || 'RP 录入页');
    } else {
      $('tabInfo').innerHTML = '<span class="badge wait">未连接</span> 当前不是 RP 录入页';
      show($('pageWarn'), true);
    }

    // 出厂名单合并进来（只补缺失的人，绝不覆盖已有修改）
    const people0 = await S.getPeople();
    const merged = S.mergeFactoryPeople(people0);
    if (merged.length > people0.length) await S.savePeople(merged);
    people = merged;
    const st = await S.getSettings();
    seq = S.cloneSeq(st.humanSeq);
    renderSeq();

    const c = await S.getCache();
    if (c) { cache = c; if (c.fields && c.fields.length) await doProbeSilent(c); }

    await applyTargetUrl();   // ⓪ 目标页面：把上次记住的地址填回输入框
    if (people.length && !selectedId) selectedId = people[0].id;
    renderPeople();
    applyTraceVisible();   // 步骤回执默认折叠，只显示 overview
    await syncResourceFromSelected();
  }

  function doProbeSilent(c) {
    $('probeInfo').innerHTML = '<span class="badge ok">缓存</span> 上次探测到 ' +
      ((c.fields || []).length || (c.rendered || []).length) + ' 个字段' +
      ' <button id="btnRe" style="padding:0 5px;font-size:10.5px;margin-left:4px">重新探测</button>';
    const re = $('btnRe');
    if (re) re.addEventListener('click', doProbe);
  }

  /* ---------- 事件绑定 ---------- */
  $('btnProbe').addEventListener('click', doProbe);
  $('btnScan').addEventListener('click', doScan);
  $('btnDiag').addEventListener('click', doDiag);
  $('btnInject').addEventListener('click', doInject);
  $('btnFill').addEventListener('click', doFill);
  $('btnClear').addEventListener('click', doClear);
  /* btnHuman 已并入 btnFill（合并按钮「执行预填」：先真人动作，再填入表单） */
  $('btnHumanList').addEventListener('click', () => { doHumanList(); });
  /* 步骤回执底部面板：点一下展开明细，再点收起（默认 collapsed） */
  $('btnTraceToggle').addEventListener('click', () => { traceVisible = !traceVisible; applyTraceVisible(); });
  $('btnImport').addEventListener('click', doImport);
  $('btnExport').addEventListener('click', doExport);
  $('search').addEventListener('input', renderPeople);

  /* ⓪ 目标页面：填完自动记住；两个按钮分别打开到当前页 / 新页签 */
  $('targetUrl').addEventListener('change', () => { S.set(TARGET_URL_KEY, targetUrlValue()); });
  $('btnOpenHere').addEventListener('click', () => { doOpenUrl(false); });
  $('btnOpenNew').addEventListener('click', () => { doOpenUrl(true); });

  /* 名单里两列直接改：改完即存（不用再点保存）。
     点进输入框时不要触发「选中该行」的重绘 —— 否则焦点会被打断。 */
  $('peopleList').addEventListener('click', (e) => {
    const t = e.target;
    const del = t.closest('[data-del]');
    if (del) {
      e.stopPropagation();
      if (!confirm('删除该人员？')) return;
      S.removePerson(del.getAttribute('data-del')).then(async () => {
        people = await S.getPeople();
        if (selectedId === del.getAttribute('data-del')) selectedId = null;
        renderPeople();
      });
      return;
    }
    if (t.tagName && String(t.tagName).toLowerCase() === 'input') return;
    const item = t.closest('.p-item');
    if (item) selectPerson(item.getAttribute('data-id'));
  });

  $('peopleList').addEventListener('change', async (e) => {
    const t = e.target;
    const pr = t.getAttribute && t.getAttribute('data-pr');
    if (pr) { selectPerson(pr); return; }   // 单选按钮：选中即同步 Resource
    const pn = t.getAttribute && t.getAttribute('data-pn');
    const pc = t.getAttribute && t.getAttribute('data-pc');
    if (!pn && !pc) return;
    const p = people.find((x) => x.id === (pn || pc));
    if (!p) return;
    if (pn) {
      const v = String(t.value || '').trim();
      if (!v) { t.value = p.name; return; }        // 姓名不能空
      p.name = v;
    } else {
      p.fields = p.fields || {};
      p.fields[ITCODE_KEY] = String(t.value || '').trim();
    }
    await S.upsertPerson(p);
    people = await S.getPeople();
    renderPeople();
  });

  $('btnAdd').addEventListener('click', async () => {
    const p = await S.upsertPerson({ name: '新人员', fields: {} });
    people = await S.getPeople();
    selectedId = p.id;
    renderPeople();
    await syncResourceFromSelected();
    const first = $('peopleList').querySelector('input[data-pn="' + p.id + '"]');
    if (first) { first.focus(); first.select(); }
  });

  /* 手动选触发字段相关绑定已移除（功能已删除） */

  /* ---------- ①真人动作：触发顺序 ---------- */
  $('btnAddSeq').addEventListener('click', async () => {
    seq.push({ name: '', value: '', control: 'optionset', enabled: true });
    renderSeq();
    const rows = $('seqList').querySelectorAll('input[data-sq-name]');
    if (rows.length) rows[rows.length - 1].focus();
    $('seqInfo').innerHTML = '<span class="muted">填好字段名与值后即生效（自动保存）</span>';
  });

  $('btnSeqDedup').addEventListener('click', () => { dedupSeq(); });
  $('btnImportMonths').addEventListener('click', () => { doImportMonths(); });

  $('seqList').addEventListener('change', (e) => { collectSeq(); });

  $('seqList').addEventListener('click', async (e) => {
    const t = e.target;
    const up = t.getAttribute && t.getAttribute('data-sq-up');
    const dn = t.getAttribute && t.getAttribute('data-sq-dn');
    const rm = t.getAttribute && t.getAttribute('data-sq-rm');
    if (up == null && dn == null && rm == null) return;
    await collectSeq();
    const i = Number(up != null ? up : (dn != null ? dn : rm));
    if (rm != null) seq.splice(i, 1);
    else {
      const j = dn != null ? i + 1 : i - 1;
      if (j < 0 || j >= seq.length) return;
      const tmp = seq[i]; seq[i] = seq[j]; seq[j] = tmp;
    }
    renderSeq();
    await S.saveSettings({ humanSeq: seq });
    $('seqInfo').innerHTML = '<span class="badge ok">已保存</span> 共 ' + seq.length + ' 步';
  });

  init().catch((e) => {
    $('tabInfo').innerHTML = '<span class="badge err">初始化失败</span> ' + U.escapeHtml(e.message);
  });
})();
