/* RP Int 预填助手 — service worker。
   职责：侧边栏开关、目标页识别、把消息广播到所有 frame 并聚合结果，
   以及用 CDP 派发「可信输入」（等价于真人鼠标/键盘）完成下拉选择。 */
importScripts('lib/human.js');

const TARGET_HOST = 'lenovo-ironman-prod.crm5.dynamics.com';
const TARGET_PATH = '/main.aspx';

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

chrome.runtime.onStartup.addListener(async () => {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.sidePanel.open({ tabId: tab.id });
  } catch (e) {
    chrome.tabs.create({ url: chrome.runtime.getURL('sidepanel.html') });
  }
});

/** 给侧边栏用：判断当前标签页是不是目标录入页 */
function tabInfo(sendResponse) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const t = (tabs && tabs[0]) || {};
    sendResponse({
      tabId: t.id,
      url: t.url || '',
      title: t.title || '',
      isTarget: (t.url || '').indexOf(TARGET_HOST) >= 0 && (t.url || '').indexOf(TARGET_PATH) >= 0
    });
  });
}

/**
 * 广播消息到 tab 的所有 frame，聚合结果。
 * content script 在 all_frames 下每个 frame 都会收到；返回数组里含所有 frame 的回复。
 * 副作用：填充类操作必须只在「一个 frame」执行，否则会重复填。
 * 因此 PROBE/DIAG 用广播聚合，FILL 用 top frame 优先 + 失败回退。
 *
 * 关键：逐 frame 记录 lastError 与 URL，否则只会看到「没响应」而看不到原因
 *（例如 iframe 跨域导致 content script 未注入）。
 */
function broadcast(tabId, msg, sendResponse) {
  chrome.webNavigation.getAllFrames({ tabId: tabId }, (frames) => {
    const list = frames || [];
    const frameIds = list.length ? list.map((f) => f.frameId) : [0];
    const urlOf = {};
    list.forEach((f) => { urlOf[f.frameId] = (f.url || '').slice(0, 220); });
    if (!list.length) urlOf[0] = '(webNavigation 未返回 frame 信息)';

    let done = 0;
    const replies = [];
    const errors = [];
    frameIds.forEach((fid) => {
      chrome.tabs.sendMessage(tabId, msg, { frameId: fid }, (r) => {
        const err = chrome.runtime.lastError;
        if (err) errors.push({ frameId: fid, url: urlOf[fid] || '', error: err.message });
        else if (r) replies.push(Object.assign({ __frameId: fid }, r));
        done++;
        if (done === frameIds.length) {
          sendResponse({
            __replies: replies,
            __frames: frameIds,
            __frameUrls: frameIds.map((f) => ({ frameId: f, url: urlOf[f] || '' })),
            __errors: errors
          });
        }
      });
    });
  });
}

/**
 * 主动注入 content script（目标系统 的 iframe 可能静态注入失败）。
 * scripting 权限已在 manifest 申请；跨域 frame 会注入失败并报错，据此可判断原因。
 */
function injectAllFrames(tabId, sendResponse) {
  const FILES = ['lib/util.js', 'lib/probe.js', 'lib/filler.js', 'content.js'];
  chrome.webNavigation.getAllFrames({ tabId: tabId }, (frames) => {
    const list = frames || [];
    const frameIds = list.length ? list.map((f) => f.frameId) : [0];
    const urlOf = {};
    list.forEach((f) => { urlOf[f.frameId] = (f.url || '').slice(0, 220); });

    let done = 0;
    const results = [];
    frameIds.forEach((fid) => {
      chrome.scripting.executeScript({
        target: { tabId: tabId, frameIds: [fid] },
        files: FILES
      }, (res) => {
        const err = chrome.runtime.lastError;
        results.push({
          frameId: fid,
          url: urlOf[fid] || '',
          ok: !err,
          error: err ? err.message : ''
        });
        done++;
        if (done === frameIds.length) {
          const okCount = results.filter((x) => x.ok).length;
          sendResponse({
            injected: okCount,
            total: results.length,
            results: results
          });
        }
      });
    });
  });
}

/* ============================================================
   真人动作：CDP 可信输入
   ------------------------------------------------------------
   content script 里 dispatchEvent 出来的事件 isTrusted=false，
   目标系统/Fluent UI 可以不认；CDP 的 Input.dispatchMouseEvent 派发的是
   **可信事件**，页面分不清是真人还是程序，联动一定会触发。
   代价：attach 期间该标签页顶部会显示「正在受自动测试软件控制」的提示条，
   且该页面不能同时开着 DevTools（会抢调试通道）。
   ============================================================ */
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

const cdpAttached = new Set();

function cdpSend(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId: tabId }, method, params || {}, (r) => {
      const e = chrome.runtime.lastError;
      if (e) reject(new Error(method + ' → ' + e.message));
      else resolve(r);
    });
  });
}

function cdpAttach(tabId) {
  if (cdpAttached.has(tabId)) return Promise.resolve();
  return new Promise((resolve, reject) => {
    try {
      chrome.debugger.attach({ tabId: tabId }, '1.3', () => {
        const e = chrome.runtime.lastError;
        if (e) reject(new Error(e.message));
        else { cdpAttached.add(tabId); resolve(); }
      });
    } catch (e) { reject(e); }
  });
}

function cdpDetach(tabId) {
  if (!cdpAttached.has(tabId)) return Promise.resolve();
  return new Promise((resolve) => {
    chrome.debugger.detach({ tabId: tabId }, () => { cdpAttached.delete(tabId); resolve(); });
  });
}

async function cdpMove(tabId, x, y) {
  await cdpSend(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x: x, y: y, buttons: 0 });
}

/** 真人点击：移动 → 按下 → 释放（中间留间隔，模拟人手） */
async function cdpClick(tabId, x, y) {
  await cdpMove(tabId, x, y);
  await sleep(60);
  await cdpSend(tabId, 'Input.dispatchMouseEvent',
    { type: 'mousePressed', x: x, y: y, button: 'left', buttons: 1, clickCount: 1 });
  await sleep(75);
  await cdpSend(tabId, 'Input.dispatchMouseEvent',
    { type: 'mouseReleased', x: x, y: y, button: 'left', buttons: 0, clickCount: 1 });
}

const KEYMAP = {
  ArrowDown: { key: 'ArrowDown', code: 'ArrowDown', vk: 40 },
  ArrowUp: { key: 'ArrowUp', code: 'ArrowUp', vk: 38 },
  Enter: { key: 'Enter', code: 'Enter', vk: 13 },
  Escape: { key: 'Escape', code: 'Escape', vk: 27 },
  Tab: { key: 'Tab', code: 'Tab', vk: 9 },
  Home: { key: 'Home', code: 'Home', vk: 36 },
  End: { key: 'End', code: 'End', vk: 35 },
  Delete: { key: 'Delete', code: 'Delete', vk: 46 },
  Backspace: { key: 'Backspace', code: 'Backspace', vk: 8 }
};
const CTRL_MOD = 2;

/** 可打印字符的键元数据（CDP 需要 key/code/虚拟键码才像真人按键） */
function keyMeta(ch) {
  const c = String(ch);
  if (/^[a-zA-Z]$/.test(c)) {
    const up = c.toUpperCase();
    return { key: up, code: 'Key' + up, vk: up.charCodeAt(0) };   // 'A' → 65
  }
  if (/^[0-9]$/.test(c)) {
    return { key: c, code: 'Digit' + c, vk: c.charCodeAt(0) };    // '0' → 48
  }
  if (c === ' ') return { key: ' ', code: 'Space', vk: 32 };
  return { key: c, code: '', vk: 0 };
}

async function cdpKey(tabId, k) {
  if (k === 'SelectAll') {
    /* Ctrl+A：Control 与 'a' 都用 **rawKeyDown**（不带 text）。
       真实事故：'a' 用带 text 的 keyDown 时，字符会被真的插进输入框，
       表现为「第一次输入的值开头多一个 a」（aLI2500347）。
       rawKeyDown 只派发按键、不产生字符，全选的默认动作照常触发。 */
    await cdpSend(tabId, 'Input.dispatchKeyEvent', {
      type: 'rawKeyDown', key: 'Control', code: 'ControlLeft',
      windowsVirtualKeyCode: 17, nativeVirtualKeyCode: 17, modifiers: CTRL_MOD
    });
    await cdpSend(tabId, 'Input.dispatchKeyEvent', {
      type: 'rawKeyDown', key: 'a', code: 'KeyA',
      windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65, modifiers: CTRL_MOD
    });
    await cdpSend(tabId, 'Input.dispatchKeyEvent', {
      type: 'keyUp', key: 'a', code: 'KeyA',
      windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65, modifiers: CTRL_MOD
    });
    await cdpSend(tabId, 'Input.dispatchKeyEvent', {
      type: 'keyUp', key: 'Control', code: 'ControlLeft',
      windowsVirtualKeyCode: 17, nativeVirtualKeyCode: 17, modifiers: 0
    });
    return;
  }
  const m = KEYMAP[k];
  if (m) {
    for (const type of ['keyDown', 'keyUp']) {
      await cdpSend(tabId, 'Input.dispatchKeyEvent', {
        type: type, key: m.key, code: m.code,
        windowsVirtualKeyCode: m.vk, nativeVirtualKeyCode: m.vk
      });
    }
    return;
  }
  /* 单个字符：keyDown（带 text）+ keyUp 两步就够。
     ⚠️ 千万不要再补发一次 type:'char' —— CDP 里 keyDown 带 text 就已经把字符插进去了，
     再发 char 会插第二遍。曾经的 bug：输入 LI2500347 结果变成 LLII22550000334477
     （每个字符重复一遍）。 */
  const meta = keyMeta(k);
  const base = {
    key: meta.key, windowsVirtualKeyCode: meta.vk, nativeVirtualKeyCode: meta.vk
  };
  if (meta.code) base.code = meta.code;
  await cdpSend(tabId, 'Input.dispatchKeyEvent',
    Object.assign({ type: 'keyDown', text: k }, base));
  await cdpSend(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, base));
}

/** 向 top frame 的 content script 问话 */
function ask(tabId, type, payload) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, Object.assign({ type: type }, payload || {}),
      { frameId: 0 }, (r) => {
        if (chrome.runtime.lastError) resolve({ __error: chrome.runtime.lastError.message });
        else resolve(r || { __error: '无响应' });
      });
  });
}

function makeCdpIo() {
  return {
    sleep: sleep,
    locate: (tabId, spec) => ask(tabId, 'RP_HUMAN_LOCATE', spec),
    locateInput: (tabId, spec) => ask(tabId, 'RP_HUMAN_LOCATE', Object.assign({ mode: 'input' }, spec)),
    options: async (tabId) => {
      const r = await ask(tabId, 'RP_HUMAN_OPTIONS', {});
      return (r && r.list) || [];
    },
    activeOption: (tabId) => ask(tabId, 'RP_HUMAN_ACTIVE', {}),
    verify: (tabId, spec) => ask(tabId, 'RP_HUMAN_VERIFY', spec),
    /* 回读必须带 mode:'input' —— 要读的是**输入框里的 value**，不是下拉触发器的
       显示文本。真实事故：verify 读的是 trigger（button/span），文本/搜索框的
       回读永远是空 → 输入自检判定「没输进去」→ 又输入一遍（FY26FY26）。 */
    readValue: (tabId, spec) => ask(tabId, 'RP_HUMAN_VERIFY', Object.assign({ mode: 'input' }, spec)),
    moveAt: (tabId, x, y) => cdpMove(tabId, x, y),
    clickAt: (tabId, x, y) => cdpClick(tabId, x, y),
    pressKey: (tabId, k) => cdpKey(tabId, k),
    /** 逐字输入：每个字符都是可信按键，目标系统 才会真的发搜索请求 */
    typeText: async (tabId, text) => {
      const s = String(text == null ? '' : text);
      for (const ch of s) {
        await cdpKey(tabId, ch);
        await sleep(45);
      }
    }
  };
}

/** 用可信输入填一个搜索字段并选第一条结果 */
async function humanLookup(tabId, spec) {
  try {
    await cdpAttach(tabId);
    const runner = RPHuman.createRunner(makeCdpIo());
    const r = await runner.pickLookup(tabId, spec);
    r.mode = 'cdp';
    return r;
  } catch (e) {
    return {
      ok: false, mode: 'cdp-failed', label: spec && (spec.displayName || spec.schemaName),
      reason: '可信输入通道不可用：' + (e && e.message), steps: []
    };
  } finally {
    try { await cdpDetach(tabId); } catch (e) { /* noop */ }
  }
}

/** 用可信输入完成一次下拉选择；CDP 不可用时退化为 content script 合成事件 */
/** 合成事件兜底（可信输入不可用时）：只对下拉有效，搜索/文本无意义 */
async function fallbackOne(tabId, spec, why) {
  const r = await ask(tabId, 'RP_SELECT_ONE', {
    schemaName: (spec && spec.schemaName) || '', displayName: (spec && spec.displayName) || '',
    value: (spec && spec.value) || ''
  });
  return {
    ok: !!r.ok, label: (spec && (spec.displayName || spec.schemaName)) || '',
    value: (spec && spec.value) || '', mode: 'cdp-failed',
    via: r.ok ? 'dom-synthetic' : '',
    reason: (why ? why + '；' : '') + (r.reason || r.error || (r.ok ? '' : '合成事件也没选上')),
    fallback: { available: (r.available || []).slice(0, 20), shown: r.shown || '' },
    steps: []
  };
}

/** 一次 attach 跑完整串（顺序 = specs 数组顺序），跑完统一 detach */
async function humanSequence(tabId, specs) {
  const list = specs || [];
  let res;
  try {
    await cdpAttach(tabId);
    const runner = RPHuman.createRunner(makeCdpIo());
    res = await runner.runSequence(tabId, list);
    res.mode = 'cdp';
  } catch (e) {
    res = {
      total: list.length, ok: 0, failed: list.length, expanded: false, results: [],
      mode: 'cdp-failed',
      error: '可信输入通道不可用：' + (e && e.message) +
        '　（常见原因：该页面开着 DevTools、或扩展未获得调试权限。已改用普通合成事件重试）'
    };
  } finally {
    try { await cdpDetach(tabId); } catch (e) { /* noop */ }
  }

  if (res.mode === 'cdp-failed') {
    const out = [];
    for (const s of list) { out.push(await fallbackOne(tabId, s, res.error)); await sleep(300); }
    res.results = out;
    res.ok = out.filter((x) => x.ok).length;
    res.failed = out.length - res.ok;
    return res;
  }

  // 串跑通了，但个别下拉没选上 → 对这几项补一次合成事件
  for (let i = 0; i < res.results.length; i++) {
    const r = res.results[i];
    if (r.ok) continue;
    const c = String((list[i] && list[i].control) || 'optionset').toLowerCase();
    if (c !== 'optionset') continue;   // 搜索/文本没有合成事件等价物
    const fb = await fallbackOne(tabId, list[i], '');
    res.results[i].fallback = fb.fallback;
    if (fb.ok) {
      res.results[i].ok = true;
      res.results[i].via = 'dom-synthetic';
      res.results[i].reason = '';
    }
  }
  res.ok = res.results.filter((x) => x.ok).length;
  res.failed = res.results.length - res.ok;
  return res;
}

async function humanPick(tabId, spec) {
  const r = await humanSequence(tabId, [spec]);
  return (r.results && r.results[0]) || { ok: false, reason: r.error || '未知错误' };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'RP_TAB_INFO') {
    tabInfo(sendResponse);
    return true;
  }

  // 打开「目标页面 URL」：到当前标签页，或新开一个标签页
  if (msg.type === 'RP_OPEN_URL') {
    const url = String(msg.url || '').trim();
    if (!/^https?:\/\//i.test(url)) { sendResponse({ error: 'URL 必须以 http:// 或 https:// 开头' }); return true; }
    if (msg.newTab) {
      chrome.tabs.create({ url: url }, (t) => {
        sendResponse(t && t.id != null
          ? { ok: true, tabId: t.id }
          : { error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || '打开新标签页失败' });
      });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const t = (tabs && tabs[0]) || {};
        if (!t.id) { sendResponse({ error: '找不到当前标签页' }); return; }
        chrome.tabs.update(t.id, { url: url }, () => {
          sendResponse(chrome.runtime.lastError
            ? { error: chrome.runtime.lastError.message } : { ok: true, tabId: t.id });
        });
      });
    }
    return true;
  }

  // 探测 / 诊断：广播到所有 frame 聚合
  if (msg.type === 'RP_BROADCAST_PROBE' || msg.type === 'RP_BROADCAST_DIAG') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = (tabs && tabs[0]) || {};
      if (!t.id) { sendResponse({ error: '找不到当前标签页' }); return; }
      broadcast(t.id, { type: msg.type === 'RP_BROADCAST_PROBE' ? 'RP_PROBE' : 'RP_DIAG' }, sendResponse);
    });
    return true;
  }

  // 主动注入：静态注入失败时的兜底（目标系统 的 iframe 常需手动补注入）
  if (msg.type === 'RP_INJECT') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = (tabs && tabs[0]) || {};
      if (!t.id) { sendResponse({ error: '找不到当前标签页' }); return; }
      injectAllFrames(t.id, sendResponse);
    });
    return true;
  }

  // 单独选下拉：只发 top frame
  if (msg.type === 'RP_SELECT_ONE') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = (tabs && tabs[0]) || {};
      if (!t.id) { sendResponse({ error: '找不到当前标签页' }); return; }
      chrome.tabs.sendMessage(t.id,
        { type: 'RP_SELECT_ONE', schemaName: msg.schemaName || '',
          displayName: msg.displayName || '', value: msg.value || '' },
        { frameId: 0 },
        (r) => sendResponse(chrome.runtime.lastError
          ? { error: chrome.runtime.lastError.message } : (r || { error: '无响应' })));
    });
    return true;
  }

  // 搜索字段：填关键字并用可信输入选第一条结果
  if (msg.type === 'RP_HUMAN_LOOKUP') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const t = (tabs && tabs[0]) || {};
      if (!t.id) { sendResponse({ error: '找不到当前标签页' }); return; }
      const specs = msg.specs || [];
      const out = [];
      for (let i = 0; i < specs.length; i++) {
        if (i > 0) await sleep(700);
        out.push(await humanLookup(t.id, specs[i]));
      }
      sendResponse({
        total: out.length, ok: out.filter((x) => x.ok).length,
        failed: out.filter((x) => !x.ok).length, results: out
      });
    });
    return true;
  }

  // 列出页面上所有下拉字段（核对字段真实名称用）
  if (msg.type === 'RP_HUMAN_LIST') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = (tabs && tabs[0]) || {};
      if (!t.id) { sendResponse({ error: '找不到当前标签页' }); return; }
      ask(t.id, 'RP_HUMAN_LIST', {}).then((r) => sendResponse(r || { list: [] }));
    });
    return true;
  }

  // 真人动作：用可信输入选下拉（可一次多个字段）
  if (msg.type === 'RP_HUMAN_PICK') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const t = (tabs && tabs[0]) || {};
      if (!t.id) { sendResponse({ error: '找不到当前标签页' }); return; }
      // 一次 attach 跑完整串：顺序 = 侧边栏配置的顺序（有先后依赖，不能重排）
      const r = await humanSequence(t.id, msg.specs || []);
      sendResponse({
        total: r.total, ok: r.ok, failed: r.failed,
        expanded: r.expanded, mode: r.mode, error: r.error || '',
        results: r.results || []
      });
    });
    return true;
  }

  // 填充：只发到 top frame，由 content script 自行遍历 iframe（避免重复填）
  if (msg.type === 'RP_FILL_TOP') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = (tabs && tabs[0]) || {};
      if (!t.id) { sendResponse({ error: '找不到当前标签页' }); return; }
      chrome.tabs.sendMessage(t.id,
        { type: 'RP_FILL', plan: msg.plan || [], displayMap: msg.displayMap || {}, opts: msg.opts || {} },
        { frameId: 0 },
        (r) => sendResponse(chrome.runtime.lastError ? { error: chrome.runtime.lastError.message } : (r || { error: '无响应' })));
    });
    return true;
  }
});
